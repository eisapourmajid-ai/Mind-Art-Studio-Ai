# Mind Art Studio AI — Package Manifest

**Generated:** 2026-08-11
**Branch:** arena/019ff0ad-mind-art-studio-ai
**Commit:** 294454a
**Status:** Approved by Majid

## Load Order

The four governing files load in this order. Each layer may reference the layers above it.

| Order | File | Role |
|-------|------|------|
| 1 | `system/PROJECT_INSTRUCTIONS.md` | Routing, behavior, permission |
| 2 | `system/00_IDENTITY.md` | Who the studio is |
| 3 | `system/01_CORE.md` | How the system thinks |
| 4 | `system/02_LIBRARY.md` | What the system has learned |

## Contents

| Path | Description |
|------|-------------|
| `system/PROJECT_INSTRUCTIONS.md` | Project Operating Contract v3.0 — 10 modules, 12-state workflow machine |
| `system/00_IDENTITY.md` | 16 sections — identity, philosophy, persona, and the Studio Reality Layer (09–16) |
| `system/01_CORE.md` | 41 sections — thinking, workflow, QA, and the Operational Decision Engine (41) |
| `system/02_LIBRARY.md` | 24 sections — knowledge base, provenance, and the Knowledge Gap Register (22) |
| `FULL_CORE_BUNDLE.md` | All four files concatenated in load order, single document |
| `system/_intake/DATA_REQUEST.md` | Open data requests to Majid, by tier |
| `system/_intake/INTAKE_LOG.md` | Placement ledger — where each dictated item landed |
| `system/PROTOCOL/` | Development directive and update proposal template |
| `docs/DEVELOPMENT_GOVERNANCE.md` | Governance rules for the repository |
| `README.md` | Bilingual project overview |
| `LICENSE` | MIT, Copyright (c) 2026 Majid Eisapour |

## Current Knowledge Maturity

**K1 for most domains, K0 for location, material, cost, and benchmark.**

The schemas exist; the knowledge does not yet. Seven open knowledge gaps are
registered at `02_LIBRARY.md` 22.02. Every unfilled field carries the literal
value `Undefined` — never an assumed value.
